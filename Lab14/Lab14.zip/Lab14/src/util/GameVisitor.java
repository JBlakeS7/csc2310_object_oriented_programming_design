package util;

public interface GameVisitor
{
	public void visit(brass.BrassGame brass_game);
}
