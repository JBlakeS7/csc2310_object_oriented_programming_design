package util;

public interface GameAccept
{
	public void accept(GameVisitor game_visitor);
}
