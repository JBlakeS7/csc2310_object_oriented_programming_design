package pqsort;

public class PQException extends RuntimeException
{
	public PQException(String msg)
	{
		super(msg);
	}
}