package brass;

interface BrassDemandTrackFunction
{
	public int getBrassDemandTrackValue(int demand_index);
}
