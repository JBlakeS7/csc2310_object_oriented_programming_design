package mastermind;

public interface MasterMindState
{
   public void mouseClicked(int x_click, int y_click);
}