package mastermind;

class MasterMindGameOverState implements MasterMindState
{
	private MasterMind state;
	
	public MasterMindGameOverState(MasterMind state)
	{
		this.state = state;
	}
	public void mouseClicked(int x_click, int y_click)
	{	
	}
}