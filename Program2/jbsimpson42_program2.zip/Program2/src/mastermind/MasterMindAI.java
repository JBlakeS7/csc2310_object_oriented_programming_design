package mastermind;

public interface MasterMindAI
{
   public Guess nextGuess();
}