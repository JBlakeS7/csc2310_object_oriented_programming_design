package mastermind;

public class MasterMindDriver
{
	//entry point
   public static void main(String[] args)
   {
      MasterMind mm = new MasterMind();
   }
}
   