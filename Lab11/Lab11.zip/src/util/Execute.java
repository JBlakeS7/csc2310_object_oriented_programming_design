package util;

public interface Execute<E>
{
   public void execute(Command<E> command);
}
