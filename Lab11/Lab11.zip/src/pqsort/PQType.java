package pqsort;

public enum PQType {TREE, LIST};
