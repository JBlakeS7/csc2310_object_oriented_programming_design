package util;

public interface FindCommand<E> extends Command<E>
{
	public java.util.List<Integer> getList();
}
