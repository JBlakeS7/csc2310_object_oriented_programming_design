package brass;

public class BrassDriver
{
	
	public static void main(String[] args)
   {
	   int num_players;
	   
		//DO THIS
		//obtain the number of players from the args array
		//use try-catch as necessary (NumberFormatException)
		//the default value for number of players is 4 in the case of a problem
		//or if no arguments have been passed to main
	   
	   
	   
	   
		BrassGame brass_game = new BrassGame(num_players);
   }
}
