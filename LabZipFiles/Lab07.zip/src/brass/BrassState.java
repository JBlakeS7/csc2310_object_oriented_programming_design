package brass;

public interface BrassState
{
	public void mouseClicked(int x_click, int y_click);
}
