package brass;

//DO THIS
//a CANAL costs 3, a RAIL costs 5, and a SECOND_RAIL costs 10
enum BrassLinkCostEnum
{
	
	
	
	
	
};

