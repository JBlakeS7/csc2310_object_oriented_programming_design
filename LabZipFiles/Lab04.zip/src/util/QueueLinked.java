package util;

public class QueueLinked
{

  // circular references
  private Node tail;
  private int size;
  
  public QueueLinked() 
  {
    tail = null;  
    size = 0; 
  }  
  
  public boolean isEmpty() 
  {
    return tail == null;
  } 

  public int size()
  {
    return size;
  }

  public void dequeueAll() 
  {
    if (tail != null)
    {
       tail.setNext(null);
    }

    tail = null;
    size = 0;
  } 

  public Object peek()
  {
    if (!isEmpty()) 
    {  
      // queue is not empty; retrieve front
      Node head = tail.getNext();
      return head.getItem();
    }
    else 
    {
      return null;
    }  
  }  
 
  public void enqueue(Object item)
  {
    Node node = new Node(item);

    // insert the new node
    if (isEmpty()) 
    {
      // insertion into empty queue
      node.setNext(node);
    }
    else 
    {
      // insertion into nonempty queue
      node.setNext(tail.getNext());
      tail.setNext(node);
    }  

    tail = node;  // new node is at back
    size++;
  }  

  public Object dequeue() 
  {
    if (!isEmpty()) 
    {
      // queue is not empty; remove front
      Node head = tail.getNext();
      if (head == tail) 
      {  
        // one node in queue
        tail.setNext(null);  //otherwise, won't be garbage collected
        tail = null;           
      }
      else 
      {
        tail.setNext(head.getNext());
      } 
      size--;
      return head.getItem();
    }
    else 
    {
      return null;
    }  
  } 
   
} 