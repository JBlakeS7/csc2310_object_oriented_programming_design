package util;

public class StackLinked
{
   private Node top;
   private int size;

   public StackLinked() 
   {
      top = null; 
      size = 0;
   } 
  
   public boolean isEmpty() 
   {
      return size == 0;
   }  

   public int size()
   {
      return size;
   }

   public void popAll() 
   {
      top = null;
      size = 0;
   }  

   public Object peek()
   {
	   if (isEmpty()) return null;
	   return top.getItem();
   }  

   public void push(Object item)
   {
      Node node = new Node(item);
      node.setNext(top);
      top = node;
      size++;
   }  

   public Object pop()
   {
	   if (isEmpty()) return null;

         Object temp = top.getItem();
         top = top.getNext();
         size--;
         return temp;
   } 
}
