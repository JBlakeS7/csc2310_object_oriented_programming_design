package brass;

public class BrassDriver
{
	public static void main(String[] args)
   {
		BrassGame brass_game = new BrassGame();
   }
}
