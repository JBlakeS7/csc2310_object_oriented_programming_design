package brass;

interface BrassComputerPlayer
{
	public BrassComputerPlayerAction getBrassMove();
}
